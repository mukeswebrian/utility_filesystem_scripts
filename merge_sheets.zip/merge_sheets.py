from openpyxl import load_workbook
import os
import pandas as pd

filename = 'seperate.xlsx'
wb = load_workbook(filename)

sheets = [i.__str__().split('"')[1] for i in wb.worksheets]

data = []

for sheet in sheets:
	sheet_data = pd.read_excel(filename, sheet_name=sheet)
	
	new_col = pd.Series([sheet for i in sheet_data.index], index=sheet_data.index, name='source_sheet')

	data.append(sheet_data.join(new_col))
	
data = pd.concat(data)
data.reset_index(drop=True).to_excel('combined.xlsx')
	
	

