Author: Brian Mukeswe
Date: June 23, 2020

Purpose: This script merges tables on different tabs of a spreadsheet into a single table.
Note: The tables must have identical coulumns names.

REQUIREMENTS: You need a working installation of Python 3 on your PC in order to run this script.
			  Python can be downloaded fro free from here: https://www.python.org/downloads/

Instructions:
step 1: Save the spreadsheet containing seperate tables as 'seperate.xlsx' to the same
		directory as the script.
		
step 2: double click 'RUN.bat' to execute the script. A new file named 'combined' will be
		created in the same directory.